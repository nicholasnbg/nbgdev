# v1.2.7
## 01/06/2016

2. [](#improved)
    * Removed extraneous encoding

# v1.2.6
## 10/07/2015

2. [](#improved)
    * Added `active` class on active taxonomies

# v1.2.5
## 07/19/2015

2. [](#improved)
    * Set the taxonomy type from the taxonomy being passed in

# v1.2.4
## 02/19/2015

2. [](#improved)
    * Implemented new `param_sep` variable from Grav 0.9.18

# v1.2.3
## 02/05/2015

2. [](#improved)
    * Added support for HHVM

# v1.2.2
## 01/09/2015

2. [](#improved)
    * NOTE: BREAKING CHANGE: Moved templates into `partials/` subfolder for consistency.

# v1.2.1
## 01/07/2015

1. [](#bugfix)
    * Support for numeric taxonomy values

# v1.2.0
## 11/30/2014

1. [](#new)
    * ChangeLog started...
